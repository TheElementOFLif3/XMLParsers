package com.example.xml;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;

public class XmlParser {

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
        try {
            // Load the XML document
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(XmlParser.class.getClassLoader().getResourceAsStream("Books.xml"));


            // Get the root element
            Element root = document.getDocumentElement();

            // Get all book elements
            NodeList bookList = root.getElementsByTagName("book");

            // Iterate over the book elements
            for (int i = 0; i < bookList.getLength(); i++) {
                Element book = (Element) bookList.item(i);

                // Get the book details
                String title = getTextContent(book, "title");
                String author = getTextContent(book, "author");
                String genre = getTextContent(book, "genre");
                double price = Double.parseDouble(getTextContent(book, "price"));
                String publishDate = getTextContent(book, "publish_date");

                // Check if the book matches the criteria
                if (price > 10 && publishDate.compareTo("2005-01-01") > 0) {
                    System.out.println("Title: " + title);
                    System.out.println("Author: " + author);
                    System.out.println("Genre: " + genre);
                    System.out.println("Price: " + price);
                    System.out.println("Publish Date: " + publishDate);
                    System.out.println("Description: " + getTextContent(book, "description"));
                    System.out.println();
                }
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static String getTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        Node node = nodeList.item(0);
        return node.getTextContent();
    }
}
